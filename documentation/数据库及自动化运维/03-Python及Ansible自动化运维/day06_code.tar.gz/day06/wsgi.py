import json

import views

def application(env, start_response):
    start_response('200 OK', [('Content-Type','text/html')])
    if env['PATH_INFO'] == '/':
        return [views.handler_index()]
    elif env['PATH_INFO'] == '/bootstrap/css/bootstrap.css':
        start_response('200 OK', [('Content-Type', 'text/css')])
        return [views.handler_css()]
    elif env['PATH_INFO'] == '/server_list':
        start_response('200 OK', [('Content-Type','text/html')])
        return [views.server_list()]
        
    elif env['PATH_INFO'] == "/cache":
        start_response('200 OK', [('Content-Type','text/html')])
        return [views.mysql_or_cache()]

    else:
        start_response('404 error', [('Content-Type','text/html')])
        return [b"404"]
