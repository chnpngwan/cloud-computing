import time, json

import models, cache


def handler_index():
    """
    以二进制方式返回首页文件的内容，并替换文件中的变量为当前时间
    """
    dt = time.strftime(r"%Y%-m-%d %H:%M:%S")
    with open('templates/index.html', 'r',
               encoding='utf-8') as f:
        content = f.read()
        content = content.replace("{{now_dt}}", dt)
    return content.encode()

def handler_css():
    file = '/root/python_code/day06/bootstrap/css/bootstrap.css'
    with open(file, 'rb') as f:
        content = f.read()
        return content


def server_data():
    conn, cursor = models.mysql_conn()
    sql = "select id, host_name, os from base_info;"
    data = models.mysql_query(cursor, sql)
    models.mysql_close(cursor, conn)
    return data

def server_list():
    tr_tpl = """
            <tr>
                <td>{id}</td>
                <td>{host_name}</td>
                <td>{os}</td>
            </tr>"""
    file = 'templates/server_list.html'
    data = server_data()
    tr = ''
    for row in data:
        tr += tr_tpl.format(**row)

    with open(file, 'r') as f:
        content = f.read()
        content = content.replace("{{table_tr}}", tr)
        content = content.replace("{{cache}}", "未使用缓存")
        content = content.replace("{{dt}}", "不用计时")
        return content.encode()
        
def mysql_or_cache():
    st = time.time()
    rs = cache.rs
    ex = rs.ttl("server_info")
    if ex >= 1:
        data = rs.get("server_info")
        data = json.loads(data)
    else:
        data = server_data()

        # 添加到缓存
        rs.set("server_info", json.dumps(data), ex=10)
    endt = time.time()
    use_dt = endt - st

    tr_tpl = """
            <tr>
                <td>{id}</td>
                <td>{host_name}</td>
                <td>{os}</td>
            </tr>"""
    file = 'templates/server_list.html'
    tr = ''
    for row in data:
        tr += tr_tpl.format(**row)

    with open(file, 'r') as f:
        content = f.read()
        content = content.replace("{{table_tr}}", tr)
        content = content.replace("{{cache}}", "使用缓存")
        content = content.replace("{{dt}}", str(use_dt))
        return content.encode()