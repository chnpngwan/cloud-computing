import redis
rs = redis.StrictRedis(
    host="127.0.0.1",
    password="foo",
    decode_responses=True,
    port=6379,
    db=0
)

if __name__ == "__main__":
    print(rs.keys())
