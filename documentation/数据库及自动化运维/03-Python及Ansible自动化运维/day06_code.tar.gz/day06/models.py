import pymysql

def mysql_conn():
    """
    创建连接
    返回连接对象，游标对象
    """
    conn = pymysql.connect(host="192.168.1.37",
                            user="dbuser",
                            passwd="QFedu123!", 
                            db="shark_db",
                            charset="utf8")
    # 获取游标对象
    cursor = conn.cursor(
      cursor=pymysql.cursors.DictCursor)
    return conn, cursor


def mysql_query(cursor, query_sql):
    cursor.execute(query_sql)

    return cursor.fetchall()

def mysql_close(cursor, conn):
    # 关闭游标对象
    cursor.close()

    # 关闭连接对象
    conn.close()

if __name__ == "__main__":
    query_sql = "select id, host_name, os from base_info;"
    conn, cursor = mysql_conn()
    print(mysql_query(cursor, query_sql))
    mysql_close(cursor, conn)
