import requests
# url = 'http://www.pingfandeshijie.net/di-yi-bu-01.html'
# r = requests.get(url)

# html = r.content.decode()
# html = str(r.content, encoding='urf-8')
# print(html)

# f = open('平凡的世界.html', mode='w', encoding='utf-8')
# f.write(html)
# f.close()

# with open('平凡的世界.html', mode='w', encoding='utf-8') as f:
#     f.write(html)

## 清洗数据
lines = []
with open('平凡的世界.html', mode='r', encoding='utf-8') as f:
    # content = f.read() 
    # print(content)
    for line  in  f:    
        if '<p>' in line:   
            if '<p>下一章' in line:
                break
            # # 方式一：
            # line = line[3:-5]
            # print(line)
            # 方式二：
            line = line.strip().strip('<p>').strip('</p>')
            lines.append(line+'\n')
file_name = "平凡的世界.txt"
with open(file_name, 'w', encoding="utf-8") as f:
    f.writelines(lines)


