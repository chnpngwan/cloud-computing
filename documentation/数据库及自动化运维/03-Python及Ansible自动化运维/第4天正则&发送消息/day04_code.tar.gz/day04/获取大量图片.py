import io, re

import requests

base_url = "https://www.doutula.com/photo/list/"

res = requests.get(url=base_url)

html = res.content.decode()
urls = []
enumerate
for line in html.splitlines():
    if 'data-original=' in line:
        r = re.search(r'.*data-original="(.*)".*', line)
        if r:
            url = r.groups()
            url = url[0]
            urls.append(url)
#                                                  data-original="http://img.doutula.com/production/uploads/image/2020/04/07/20200407249345_RJczYE.jpg"


for idx, img_url in enumerate(urls, 1):
    res = requests.get(url=img_url)
    file_name = f'图{idx}.jpg'
    with io.open(file_name, 'wb') as f:
        f.write(res.content)
