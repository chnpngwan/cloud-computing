"""

<img referrerpolicy="no-referrer" src="http://img.doutula.com/production/uploads/image/2020/04/07/20200407249344_RAysLl.jpg" data-original="http://img.doutula.com/production/uploads/image/2020/04/07/20200407249344_RAysLl.jpg" alt="懵了" class="img-responsive lazy image_dta loaded" data-backup="http://img.doutula.com/production/uploads/image/2020/04/07/20200407249344_RAysLl.jpg" data-was-processed="true">

"""

import requests, io

res = requests.get('http://img.doutula.com/production/uploads/image/2020/04/07/20200407249344_RAysLl.jpg')


with io.open('懵了.jpg', 'wb') as f:
    f.write(res.content)
