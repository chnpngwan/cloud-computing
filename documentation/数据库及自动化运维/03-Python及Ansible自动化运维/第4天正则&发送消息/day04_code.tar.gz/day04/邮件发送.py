# 第三方模块 yagmail
# pip3 install  yagmail

import yagmail

"""
yag = yagmail.SMTP(
            user='自己的邮箱账号',
            password='账号的授权码(不是登陆密码)',
            host='smtp.qq.com',  # 邮局的 smtp 地址
            port='端口号',       # 邮局的 smtp 端口 25 不加密, 465是加密
            smtp_ssl=False)

yag.send(to='收件箱账号',
         subject='邮件主题',
         contents='邮件内容')
"""


# 这个要刚才已经成功开通 SMTP 的邮箱账号
email_user = 'sharkyunops@126.com'

# 这个必须是客户端授权码，不是登录密码
with open('/root/.emailpwd') as f:
    pwd = f.read()[:-1]
email_pwd  = pwd

# 这个可以从邮件服务提供商获取
email_host = 'smtp.126.com'

# 邮件正文
email_content = """你不是我喜欢的那种人

却慢慢变成

我喜欢的那个人"""

yag = yagmail.SMTP(user=email_user,
                   password=email_pwd,
                   host=email_host,
                   port=465,
                   smtp_ssl=True)
# yag.send(to='sharkyunops@126.com',
#          subject='告白气球',
#          contents=email_content)
email_users = ['86000153@qq.com', 'dockerhub@163.com']
email_content = "你不讲真心话，我却在大冒险！"
yag.send(to=email_users,
    subject='告白气球',
    contents=email_content,
    attachments='/root/python_code/day04/那里没有你的心跳.png'
)





         