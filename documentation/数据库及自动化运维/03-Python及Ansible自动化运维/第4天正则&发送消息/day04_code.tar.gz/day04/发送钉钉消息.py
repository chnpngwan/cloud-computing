webhook = 'https://oapi.dingtalk.com/robot/send?access_token=ca4fedbececda29424c5b7776f6df1deca9c5cd4c5ae0f77bc722ae271095a45'

# pip3 install requests

import requests
send_content = "shark:出发"
# content = {
#     "msgtype": "text",
#     "text": {
#         "content": send_content
#     },
#     "at": {
#        # 发送给群里的所有人
#         "isAtAll": True
#     }
# }

content = {
    "msgtype": "text",
    "text": {
        "content": "出发！"
    },
    "at": {
       "atMobiles": [
            # 单独 @ 某个人，使用绑定的手机号，
            # 多个人用户英文逗号隔开
            "131xxxxxx811",
            "137xxxxxxxxx"
        ]
    }
}

headers = {"Content-Type": "application/json;charset=utf-8"}

r = requests.post(url=webhook, json=content, headers=headers)
print(r.content.decode(encoding=))