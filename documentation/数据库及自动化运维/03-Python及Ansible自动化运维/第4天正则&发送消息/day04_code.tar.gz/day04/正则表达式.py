# 内置模块 re 

"""
\w   匹配单个字母、数字、汉字(shell中没有)
      和下划线  类似于 [a-zA-Z0-9_]
\d  [0-9]
\s  单个任意的空白字符，等价于[\t\n\r\f\v]
\S  当非空白字符
"""

import re

# match
# 只在整个字符串的起始位置进行匹配

s = "isinstance yangge enumerate www.qfedu.com 1997"

r = re.match('is\w+', s)
if r:
    print(r.group())

# search
# 从开头到结尾，匹配到第一个就结束

r = re.search('a\w+', s)
if r:
    print(r.group())

li = re.findall('a\w+', s)
print(li)

# sub 替换

# 语法：
"""
sub("a\w+",    "100",        string,     2)
匹配规则,   替换成的新内容,  被搜索的对象, 有相同的话替换的次数
"""

s1 = re.sub('a\w+', '100', s)
s2 = re.sub('a\w+', '100', s, 2)
# print(s)
# print(s1)
# print(s2)

# split 相当与 awk -F'[|, ]'
s = "isinstance yangge enumerate www.qfedu.com 1997"

l2 = re.split('a', s)
# print(l2)

line = 'asdf fjdk; afed, fjek,asdf,  foo'
l3 = re.split(r'[;,\s]\s*', line)
# print(l3)


# 正则分组  
# sed -ri 's/(he)llo/\1/g'
s = "isinstance yangge enumerate www.qfedu.com 1997"
# r = re.match("is(\w+)", s)

# print(r.group(), r.groups())


# 命名分组
r = re.search("is\w+\s(?P<name>y\w+e)", s)
print(r.group())
print(r.groups())
print(   r.groupdict()  )

# findall
r = re.findall("a(\w+)", s)
print(r)









