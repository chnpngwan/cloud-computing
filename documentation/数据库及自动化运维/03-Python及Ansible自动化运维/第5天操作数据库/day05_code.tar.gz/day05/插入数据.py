import pymysql

# 创建连接
conn = pymysql.connect(host='192.168.1.37', # MySQLServer IP
                       port=3306,
                       user='dbuser',
                       passwd='QFedu123!', 
                       db='qfedu',
                       charset='utf8mb4')

# # 获取游标对象
cursor = conn.cursor(pymysql.cursors.DictCursor)

# 实例数据

info = {
    "base_info": {
        "manufacturer": "VMware, Inc.",
        "pod_name": "VMware7,1",
        "sn": "VMware-56 4d 2b 4b 91 1e 48 15-5b d2 73 9c ec 98 da 22",
        "host_name": "qfedu.com",
        "kernel": "3.10.0-957.el7.x86_64",
        "os": "CentOS Linux release 7.6.1810 (Core)"
    },
    "cpu": {
        "cpu_name": "Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz",
        "cpu_pyc": 1,
        "cpu_cores_each": 1
    },
    "memory": [
        {
            "capacity": " 8192 MB",
            "slot": " DIMM_B2",
            "model": " DDR3",
            "speed": " 1333 MT/s",
            "manufacturer": " 00CE00B380CE",
            "sn": " 82B79F71"
        },
        {
            "capacity": " 8192 MB",
            "slot": " DIMM_B3",
            "model": " DDR3",
            "speed": " 1333 MT/s",
            "manufacturer": " 00CE00B380CE",
            "sn": " 32CDDE81"
        },
        {
            "capacity": " No Module Installed",
            "slot": " DIMM_B4",
            "model": " DDR3",
            "speed": " Unknown",
            "manufacturer": "",
            "sn": ""
        },
        {
            "capacity": " 8192 MB",
            "slot": " DIMM_B5",
            "model": " DDR3",
            "speed": " 1333 MT/s",
            "manufacturer": " 00CE04B380CE",
            "sn": " 85966B82"
        },
        {
            "capacity": " 8192 MB",
            "slot": " DIMM_B6",
            "model": " DDR3",
            "speed": " 1333 MT/s",
            "manufacturer": " 000000B380CE",
            "sn": " 00000000"
        }
    ]
}

base_info = {**info["base_info"], **info["cpu"]}
keys = base_info.keys()
values = base_info.values()
# print(keys)
# print(values)
# 一次插入一条数据, 并且使用 pymysql 定义的变量占位符
sql = '''insert into base_info(
                        {},{},{},{},{},{},{},{},{}
                ) values(%s, %s, %s, %s, %s, %s, %s, %s, %s);'''

sql = sql.format(*keys)
cursor.execute(sql, tuple(values))

conn.commit()
cursor.close()
conn.close()
