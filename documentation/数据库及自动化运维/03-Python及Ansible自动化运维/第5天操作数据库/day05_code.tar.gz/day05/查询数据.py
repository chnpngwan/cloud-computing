import pymysql
# 创建连接
conn = pymysql.connect(host='192.168.1.37', # MySQLServer IP
                       port=3306,
                       user='dbuser',
                       passwd='QFedu123!', 
                       db='qfedu',
                       charset='utf8mb4')

# 获取游标对象
cursor = conn.cursor(pymysql.cursors.DictCursor)

# query_sql = "select id, host_name, os from base_info;"

# row_nums = cursor.execute(query_sql)

# print(row_nums)

query_mem = "select id, slot, model, sn from memory;"
row_nums = cursor.execute(query_mem)
print(row_nums)


# 查询的结果集，具体迭代器的特性
"""
100
10  90
20  70
70   0

"""
one_data = cursor.fetchone()
many_data = cursor.fetchmany(2)
all_data = cursor.fetchall()

cursor.close()
conn.close()
print(one_data)
print("*" * 20)
print(type(many_data))
print("*" * 20)
print(all_data)

