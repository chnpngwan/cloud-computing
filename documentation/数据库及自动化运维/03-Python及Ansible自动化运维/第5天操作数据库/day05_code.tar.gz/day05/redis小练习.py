"""
校验 id

登录功能（校验用户名密码）
  - 加密密码
保存 id

  - 产生随机数 id

获取 id

"""

import random, string, hashlib

import redis

rs = redis.StrictRedis(
    host="172.16.153.189",
    port=6379,db=0,
    decode_responses=True,
    password="foo")

def generate_sessid():
    """生产随机字符串
    Return: 返回 session id
    """
    
    # 获取基本的字符串0-9 a-z A-Z
    base_str = f"{string.digits + string.ascii_letters}"
    # 拼接
    sessid = ''.join(random.sample(base_str, 20))
    return sessid

def hash_pwd(pwd):
    """传入一串字符，进行 MD5 计算
    Keyword arguments:
    pwd -- 字符串
    Return: md5 加密值
    """
    
    password = hashlib.md5(pwd.encode('utf-8'))
    return password.hexdigest()

def save_session(name, sessid='', ex=7200):
    """保存会话信息，并存入缓存
    Keyword arguments:
    name -- 用户名
    pwd -- 加密过的密码
    sessid -- 会话 id
    Return:
    """
    rs.hset(name, "sessid", sessid)
    # 保存会话有效时间
    rs.setex(f"{name}_{sessid}", ex, sessid)


def check_session(name, sessid):
    if rs.ttl(f"{name}_{sessid}") in (-2, 0):
        return False
    else:
        return True

def login():
    """
    用户登录，验证，验证成功返回用户名
    :return 用户名和 会话 ID
    """
    while True:
        inp = input("输入用户名和密码,中间用空格隔开，比如: shark 123\n>>:").strip()
        user_pwd = inp.split()
        if len(user_pwd) == 2:
            name, source_pwd = user_pwd
        else:
            print("格式错误,请重新输入")
            continue
        # 获取加密密文
        pwd = hash_pwd(source_pwd)
        # 获取缓存中加密密文
        user = rs.hget(name, "name")
        redis_pwd = rs.hget(name, "password")
        
        # 验证用户名和密码
        if name == user and pwd == redis_pwd:
            return name, generate_sessid()
        else:
            print("用户名密码错误, 请重新输入")
            continue

def main():
    while True:
        inp = input("输入 会话 ID\n格式： name sessionid>>:").strip()
        if len(inp.split()) == 2:
            name, sessid = inp.split()
            ex = check_session(name, sessid)
        else:
            print("格式错误 name  session")
            continue
        if ex:
            print("精彩继续")
        else:
            name, sessid = login()
            save_session(name, sessid,ex=10)
            print(name, sessid)
            print("精彩继续")

if __name__ == "__main__":
    main()