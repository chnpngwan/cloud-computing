"""
比如我们想存储用户的登录信息
一般用户的登录信息有一下几点：

- 用户名  name
- 加密的密码  password
- 会话 session_id
- 会话过期时间 expiration_date

hashlib
string
random
"""

# hashlib 
# 摘要算法  哈希算法  散列算法
# 1. 无法反推
# 2. 数据是否完整
# 任意长度 ---》 固定长度的 16 进制的数字

import hashlib

hmd5 = hashlib.md5('hello'.encode())
md5 = hmd5.hexdigest()
# print(md5)


import string, random

base_str = f"{string.ascii_letters}{string.digits}"
# print(base_str)

li = random.sample(base_str, 20)
sessid = ''.join(li)

"""
用户名
密码
sessid 

hash
"shark", {"name": "shark", "pwd": "加密密码", "sessid": ''}

处理是否过期
"shark_sessid": "session id"
"""

import redis

rs = redis.StrictRedis(host="172.16.153.189",port=6379,db=0,
                  decode_responses=True,
                  password="foo")


# hmd5 = hashlib.md5("QFedu123".encode())
# pwd = hmd5.hexdigest()
# name = "shark"
# rs.hmset(name, {"name": name, "pwd": pwd, "sessid": sessid})
# rs.setex(f"{name}_{sessid}", 20 ,sessid)