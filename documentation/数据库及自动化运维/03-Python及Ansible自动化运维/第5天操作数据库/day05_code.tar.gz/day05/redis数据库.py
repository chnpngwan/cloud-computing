# NOSQL
# 存放的数据都是一个一个的键值对，数据之间互相没有任何依赖性
# redis
# 数据库 0-15 共 16 个

# pip3  install redis

import redis

rs = redis.StrictRedis(host="172.16.153.189",port=6379,db=0,
                  decode_responses=True,
                  password="foo")
# ret = rs.set("QF", "www.qfedu.com")
# print(ret)

# v = rs.get('QF')
# print(v)

#set(name, value, ex=None, px=None, nx=False, xx=False)

# rs.set("name", "shark", ex=50)

# print(rs.ttl("name"))
# print(rs.get('name'))

# rs.setex('login', 30, 1)

# print(rs.ttl("login"))
# print(rs.get("login"))

# {"n1": {"k1": 'v1', 'k2': "v2"}}

# user_info = {"name": "shark", "age": 18}

# rs.hmset("shark", user_info)

# print( rs.hget("shark", "age") )