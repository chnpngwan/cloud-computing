li = []
n = 0
for i in range(1,11):
    n += i
    li.append(n)
print(sum(li))