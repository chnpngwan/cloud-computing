import importlib, json

PLUGINS  = {
    "base_info": "plugins.base_info",
    "cpu": "plugins.cpu",
    "memory": "plugins.memory"
}
server_info = {}
for k, path in PLUGINS.items():
    mod = importlib.import_module(path)
    server_info[k] = mod.main(debug=True)

server_info = json.dumps(server_info, indent=4)
print(server_info)










