import subprocess

def exec_cmd(cmd):
    return subprocess.getoutput(cmd)