#!/usr/bin/env python3
import subprocess

prod_info = 'dmidecode -q -t 1 2>/dev/null'

ret = subprocess.getoutput(prod_info)
prod_dic = {}

map_dic = {
    "Manufacturer": "manufacturer",
    "Product Name": "pod_name",
    "Serial Number": "sn"
}

for line in ret.splitlines():
    line = line.strip()
    try:
        k, v  = line.split(": ")
        if k in map_dic:
            # k = map_dic.get(k)
            prod_dic[map_dic.get(k)] = v
    except ValueError as e:
        print(e)
# print('....>>>')
print(prod_dic)