from tools import exec_cmd

def main(debug):
    # shell 命令
    cpu_type = "grep 'model name' /proc/cpuinfo | uniq "
    cmd_cpu_pyc = "grep 'physical id' /proc/cpuinfo | sort -u | wc -l"
    cmd_cpu_cores_each = "grep 'cpu cores' /proc/cpuinfo | uniq"

    cpu_type = exec_cmd(cpu_type).split(':')[1]
    cpu_pyc = exec_cmd(cmd_cpu_pyc).strip()
    cpu_cores_each = exec_cmd(cmd_cpu_cores_each)
    cpu_cores_each = cpu_cores_each.split(': ')[1]

    return {'cpu_name': cpu_type.strip(),
    'cpu_pyc': int(cpu_pyc),
    'cpu_cores_each': int(cpu_cores_each)
    }


