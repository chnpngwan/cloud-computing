from tools import exec_cmd

def get_base():
    # 主机名
    host_name = exec_cmd('uname -n')

    # 内核
    kernel = exec_cmd('uname -r')

    # 操作系统
    os = exec_cmd('cat /etc/redhat-release')
    base_info ={
        'host_name': host_name,
        'kernel': kernel,
        'os': os.strip()
    }
    return base_info


def get_bios():
    prod_dic = {}
    bios_info = exec_cmd('dmidecode -q -t 1 2')

    map_dic = {
        "Manufacturer": "manufacturer",
        "Product Name": "pod_name",
        "Serial Number": "sn"
    }

    for line in bios_info .splitlines():
        line = line.strip()
        try:
            k, v  = line.split(": ")
            if k in map_dic:
                # k = map_dic.get(k)
                prod_dic[map_dic.get(k)] = v
        except ValueError as e:
            print(e)
    return prod_dic

def main(debug):
    prod_dic = get_bios()
    base = get_base()
    return {**prod_dic, **base}


