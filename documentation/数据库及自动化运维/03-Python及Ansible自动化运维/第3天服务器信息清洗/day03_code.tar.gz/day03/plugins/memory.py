from tools import exec_cmd

key_map = {
        'Size': 'capacity',
        'Locator': 'slot',
        'Type': 'model',
        'Speed': 'speed',
        'Manufacturer': 'manufacturer',
        'Serial Number': 'sn',
}

def get_mem(debug=None):
    if debug:
        file_name = '/root/python_code/day03/memory.txt'
        with open(file_name) as f:
            memory_str =  f.read()
    else:
        memory_str = exec_cmd('dmidecode -q -t 17')
    return memory_str

def parse(data):
    memory_list = data.split('Memory Device')[1:]
    mem_li = []
    for mem in memory_list:
        single_slot = {}
        for line in mem.splitlines():
            line = line.strip()
            if len(line.split(":")) == 2:
                k, v = line.split(":")
                if k in key_map:
                    new_k = key_map[k]
                    single_slot[new_k] = v.strip()
        mem_li.append(single_slot)
    return mem_li

def main(debug):
    data = get_mem(debug)
    return parse(data)

if __name__ == "__main__":
    print(len(main(debug=True)))
